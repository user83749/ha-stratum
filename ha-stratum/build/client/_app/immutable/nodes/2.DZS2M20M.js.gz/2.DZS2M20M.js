import{_ as m}from"../chunks/pOHzWP0b.js";export{m as component};
